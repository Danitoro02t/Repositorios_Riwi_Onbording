print("Asigna los lados correctos de un triangulo")

lado1 = "equilatero"
lado2 = "isosceles"
lado3 = "escaleno"

asignar_lado1 = input("el primer lado de un triangulo: ")
asignar_lado2 = input("el segundo lado de un triangulo: ")
asignar_lado3= input("el tercer lado de un triangulo: ")

if asignar_lado1 == lado1 and asignar_lado2 == lado2 and asignar_lado3 == lado3:
    print(f"Correcto el primer lado de un triangulo es {lado1}, el segundo lado es {lado2} y el tercer lado es {lado3}")
else: 
    print("error, vuelve a checar que estes asignado los lados correctos de un triangulo")