#print("FIRE EMBLEM FORTUNE'S WEAVE EL GOTY 2026")

#numero1 =int(input ("Dame el numero 1"))
#numero2 =int(input ("Dame el numero 2"))
#resultado= print("numero1 + numero2")
print("Welcome")
nombre=input("ingresa tu nombre: ")
edad=int(input("ingresa tu edad: "))

if edad >=18:
    print((nombre + " es mayor de edad"))
else:
    print(nombre + " no es mayor de edad")