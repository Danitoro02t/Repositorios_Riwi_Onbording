numero1 = float(input("Ingresa el primer número: "))
numero2 = float(input("Ingresa el segundo número: "))

suma = numero1 + numero2
resta = numero1 - numero2

print(f"Suma: {suma}")
print(f"Resta: {resta}")

if suma > 10:
    print("¡La suma es mayor que 10")
else:
    print("La suma no es mayor que 10")