print("bienvenido a Ecomoda")

nombre = input("Agregue su nombre: ")
producto = input ("Asigne el producto: ")
precio = float(input("Asigne el costo de este producto: "))
cantidad = int(input("Indique cuantas unidades se va a llevar: "))


subtotal = precio * cantidad


if subtotal >= 500000:
    porcentaje_desc = 0.15
elif subtotal >= 200000:
    porcentaje_desc = 0.10
else:
    porcentaje_desc = 0.00


descuento = subtotal * porcentaje_desc
total = subtotal - descuento



print("      FACTURA DE ECOMODA      ")
print("="*30)
print(f"Cliente:    {nombre}")
print(f"Producto:   {producto} (x{cantidad})")
print("-"*30)
print(f"Subtotal:   ${subtotal}")
print(f"Descuento:  ${descuento} ({porcentaje_desc * 100}%)")
print(f"Total:      ${total}")
print("="*30)
print("¡Gracias por su compra!")
