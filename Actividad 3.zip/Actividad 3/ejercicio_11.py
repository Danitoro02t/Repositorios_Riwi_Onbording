temperatura = float(input("Escribe cuál es la temperatura: "))

if temperatura < 10: 
    print("La temperatura está a menos de 10 grados, precauciones con el frío")
elif 10 <= temperatura <= 25: 
    print("La temperatura está templada, buena para salir")
elif 25 <= temperatura < 35: 
    print("La temperatura está calurosa, toma tus precauciones")
else: 
    print("La temperatura está extremadamente alta, considera lo mejor antes de salir de casa")