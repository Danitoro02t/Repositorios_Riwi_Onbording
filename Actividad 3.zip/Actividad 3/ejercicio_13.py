def mostrar_menu():
    print("\n--- Calculadora ---")
    print("1. Sumar")
    print("2. Restar")
    print("3. Multiplicar")
    print("4. Dividir")
    print("5. Salir")

def calculadora():
    while True:
        mostrar_menu()
        opcion = input("Elige una opción: ")

        if opcion == "5":
            print("Adioooos")
            break
                    
        if opcion in ("1", "2", "3", "4"):
            try:
                num1 = float(input("Ingresa el primer numero: "))
                num2 = float(input("Ingresa el segundo numero: "))
            except ValueError:
                print("Por favor, ingresa números válidos.")
                continue

            if opcion == "1":
                print(f"Resultado: {num1 + num2}")
            elif opcion == "2":
                print(f"Resultado: {num1 - num2}")
            elif opcion == "3":
                print(f"Resultado: {num1 * num2}")
            elif opcion == "4":
                if num2 == 0:
                    print("Error: No se puede dividir entre cero.")
                else:
                    print(f"Resultado: {num1 / num2}")
        else:
            print("Oopcion no valida, vuelve a intentarlo")

if __name__ == "__main__":
    calculadora()
