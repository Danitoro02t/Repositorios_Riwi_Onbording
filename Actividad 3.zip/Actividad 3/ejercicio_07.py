

edad = int(input("Binvenido al evento, porfavor Ingrese la edad: "))

if edad >=18:
    print("Eres mayor de edad, prosiga")
elif edad <0: 
    print("Error, por favor ingrese su edad de forma correcta")
else:
    print("no eres mayor de edad, tienes prohibido el acceso")
