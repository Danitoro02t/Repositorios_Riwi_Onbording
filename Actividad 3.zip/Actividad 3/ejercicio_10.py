usuario = "daniel"
contrasena= "1234"


usuario_ingresado = input("Introduce tu usuario: ")
contrasena_ingresada = input("Introduce tu contraseña: ")


if usuario_ingresado == usuario and contrasena_ingresada == contrasena:
    print("Acceso permitido. Bienvenido a tu perfil")
else:
    print("Error. Usuario o contraseña incorrectos")