
compra = float(input("Ingrese el valor de la compra: "))


if compra >= 200000:
    descuento = compra * 0.20
elif compra >= 100000:
    descuento = compra * 0.10
else:
    descuento = 0

total = compra - descuento


print(f"Descuento aplicado: ${descuento}")
print(f"Precio final a pagar: ${total}")