
nota = float(input("ingrese la nota: "))
if nota >=101: 
    print("Nota invalida, por favor ingrese la nota correcta")
elif nota >=70: 
    print("Felicidades, aprobaste")
else: 
    print("Lastima, reprobaste, suerte para la proxima")

   