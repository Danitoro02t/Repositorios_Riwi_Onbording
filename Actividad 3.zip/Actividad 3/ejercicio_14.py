print("Bienvenido a Bancolombia")

Saldo = 3000000

def mostrar_menu():
    print("\n--- Seleccione una opción ---")  
    print("1. Consultar saldo")
    print("2. Retirar dinero")
    print("3. Depositar dinero")
    print("4. Salir")

def menu():
    global Saldo  
    while True:
        mostrar_menu()
        opcion = input("Elige una opción: ")

        if opcion == "1":
            print(f"Tu saldo actual es: ${Saldo}")
            
        elif opcion == "2":
            retiro = float(input(f"Su saldo actual es ${Saldo}, cuánto desea retirar?: "))
            if retiro > Saldo:
                print("Error: Fondos insuficientes.")
            else:
                Saldo -= retiro  
                print(f"Retiro exitoso. Su nuevo saldo es: ${Saldo}")
                
        elif opcion == "3":
            deposito = float(input("¿Cuánto desea depositar?: "))
            Saldo += deposito  
            print(f"Depósito exitoso. Su nuevo saldo es: ${Saldo}")
            
        elif opcion == "4":
            print("Sesion finalizada. Gracias por usar Bancolombia")
            break
        else:
            print("Opción no valida. Por favor elija una opción del 1 al 4.")

if __name__ == "__main__":
    menu()