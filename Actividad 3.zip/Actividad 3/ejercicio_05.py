print("Welcome mi colombiano :v")

numero1 = int(input("Agrega el primer numero: "))
numero2 = int(input("Agrega el segundo numero: "))

if numero1 > numero2:
    print(f"el {numero1} es el mayor")
elif numero2 > numero1:
    print(f"el {numero2} es el mayor")
else:
    print("ambos numeros son iguales")